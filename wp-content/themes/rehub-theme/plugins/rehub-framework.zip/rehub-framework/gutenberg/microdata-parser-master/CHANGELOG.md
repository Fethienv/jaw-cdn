# Changelog

All notable changes to `microdata-parser` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com)

## Unreleased
